﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1
{
    public partial class Form1 : Form
    {
        Matricula matricula = new Matricula();

        public Form1()
        {
            InitializeComponent();
        }



        private void btnGuardar_Click(object sender, EventArgs e)
        {



            Estudiante estudiante = new Estudiante(txtCif.Text, txtNombre.Text, txtApellidos.Text,
                    dtFecha.Value, cbFacultad.Text, cbCarrera.Text);

            if (matricula.agregarISI(estudiante) == true){
                MessageBox.Show("Registro Ingresado", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LlenarDataGrid();
                limpiar();
            }
                
            
            else
            {
                MessageBox.Show("El registro es de otra carrera que no es de sistemas. No se guardara nada", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            


        }

        private void LlenarDataGrid()
        {
            dgvRegistro.DataSource = matricula.listado.ToArray();
            dgvRegistro.Refresh();
        }

        private void limpiar()
        {
           
            txtCif.Clear();
            txtNombre.Clear();
            txtApellidos.Clear();
            cbCarrera.SelectedIndex = -1;
            cbFacultad.SelectedIndex = -1;
            dtFecha.Value = DateTime.Now;
            txtCif.Focus();
        }

        private void dgvRegistro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        string nom;

        private void cbFacultad_SelectedIndexChanged(object sender, EventArgs e)
        {
            nom = cbFacultad.SelectedItem.ToString();
            llenarCbCarrera(nom);
            if (cbFacultad.SelectedItem == "Ingeniería y Arquitectura")
            {
                cbCarrera.SelectedIndex = 16;
                

            }
        }

        private void llenarCbCarrera(string nombreFacultad)
        {
            switch (nombreFacultad)
            {
                case "Ingeniería y Arquitectura":
                    cbCarrera.SelectedIndex = 16;
                    break;
                case "Ciencias Medicas":
                    cbCarrera.SelectedIndex = 3;
                    break;
                case "Marketing, Diseño y Ciencias de la Comunicación":
                    cbCarrera.SelectedIndex = 6;
                    break;
                case "Ciencias Juridicas, Humanidades y Relaciones Internacionales":
                    cbCarrera.SelectedIndex = 0;
                    break;
                case "Odontología":
                    cbCarrera.SelectedIndex = 5;
                    break;
                case "Ciencias Administrativas y Económicas":
                    cbCarrera.SelectedIndex = 10;
                    break;
                case "UAM College":
                    cbCarrera.SelectedIndex = 18;
                    break;


            }
        }

    }

}

